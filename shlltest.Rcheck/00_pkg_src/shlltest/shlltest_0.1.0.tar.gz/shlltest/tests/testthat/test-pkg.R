

test_that("one",{
  x1 <- testshlib("a")
  expect_true(TRUE)
})


test_that("two",{
  x2 <- testshlib("abc")
  expect_true(TRUE)
})

test_that("three",{
  x2 <- testshlib("abcxyz")
  expect_true(TRUE)
})

test_that("four",{
  x2 <- testshlib("aeiouy")
  expect_true(TRUE)
})


test_that("five",{
  x2 <- testshlib("z")
  expect_true(TRUE)
})
