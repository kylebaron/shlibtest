
x1 <- testshlib("abc")
x2 <- testshlib("xyz")
x3 <- testshlib("aabbccdd")

test_that("main",{
  expect_true(TRUE)
  
})

