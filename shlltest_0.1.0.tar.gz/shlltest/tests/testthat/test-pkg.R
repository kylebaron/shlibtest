
test_that("one",{
  x1 <- testshlib()
  expect_true(TRUE)
})

test_that("two",{
  x2 <- testshlib()
  expect_true(TRUE)
})

test_that("three",{
  x2 <- testshlib()
  expect_true(TRUE)
})

test_that("four",{
  x2 <- testshlib()
  expect_true(TRUE)
})

test_that("five",{
  x2 <- testshlib()
  expect_true(TRUE)
})
